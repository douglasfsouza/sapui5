sap.ui.define([
	"sap/ui/core/UIComponent"
], function (UIComponent) {
	"use strict";

	return UIComponent.extend("sap.m.sample.IconTabHeader.Component", {

		metadata: {
			manifest: "json"
		}

	});
});